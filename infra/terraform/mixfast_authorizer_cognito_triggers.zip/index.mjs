const handler = async (event) => {
  event.response.issueTokens = true;
  event.response.failAuthentication = false;
  event.response.challengeName = "CUSTOM_CHALLENGE";
  console.log(event)
  
  return event;
};

export { handler }